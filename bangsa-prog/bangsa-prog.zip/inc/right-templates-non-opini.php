<section class="right-templates">
				<div class="post">
				<img src="image/370x200.jpg">
				<div class="clear-height-14"></div>
				<button class="btn btn-green">Terkini</button>
				<button class="btn btn-default">Popular</button>
				<div class="clear-height-5"></div>
				<div class="content-post">
					<div class="content-post1">
					<div class="clear-height-20">
					<img src="image/post-content1.jpg">
					</div>
					<div class="content-post-title">
						7 Ways To Advertise Your Business For Free
					</div>
					<div class="content-post-date">
						08 Apr 2018
					</div>
					</div>
					<div class="content-post2">
					<div class="clear-height-20">
					<img src="image/post-content2.jpg">
					</div>
					<div class="content-post-title">
						15 Tips To Increase Your Adwords Profits
					</div>
					<div class="content-post-date">
						25 0ct 2018
					</div>
					</div>
					<div class="content-post2">
					<div class="clear-height-20">
					<img src="image/post-content3.jpg">
					</div>
					<div class="content-post-title">
						Direct Mail Advertising How I Made 47 325 In 30 Days By Mailing 2 200 Letters
					</div>
					<div class="content-post-date">
						05 Feb 2018
					</div>
					</div>
					<div class="content-post2">
					<div class="clear-height-20">
					<img src="image/post-content4.jpg">
					</div>
					<div class="content-post-title">
						Free Real Estate Listings
					</div>
					<div class="content-post-date">
						27 Apr 2018
					</div>
					</div>
					<div class="content-post2">
					<div class="clear-height-20">
					<img src="image/post-content5.jpg">
					</div>
					<div class="content-post-title">
						Where To Look For Cheap Brochure Printing Services
					</div>
					<div class="content-post-date">
						19 Mar 2018
					</div>
					</div>
				</div>
				<div class="clear-height-14"></div>
					<img src="image/370x80.jpg">
					<div class="clear-height-14"></div>
					<img src="image/370x80.jpg">
					<div class="clear-height-14"></div>
					<div class="polling">
						<div class="clear-height-8"></div>
					<div class="title">
						Polling
					</div>
					<div class="clear-height-8"></div>
					</div>
					<div class="polling-content">
						<div class="clear-height-20">
							<form>
								<label>Direct Mail Advertising How I Made 47 325 In 30 Days By Mailing 2 200 Letters?</label>
								<div class="radio"><input type="radio" name="vote" value="profiles">Profiles Of The Powerful Advertising Exec Steve Grasse<br/></div>
								<div class="radio">
								<input type="radio" name="vote" value="feedback">Feedback Management<br/>
								</div>
								<div class="radio">
								<input type="radio" name="vote" value="Adwords">Adwords Keyword Research For Beginners<br/>
								</div>
								<button class="btn btn-orange">
									Vote
								</button>
							</form>
						</div>
					</div>
				</div>

</section>