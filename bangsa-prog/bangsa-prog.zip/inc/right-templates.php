<section class="right-templates">
			<div class="col-md-4">
				<div class="post">
				<img src="image/370x200.jpg">
				<div class="clear-height-14"></div>
				<button class="btn btn-green">Terkini</button>
				<button class="btn btn-default">Popular</button>
				<div class="clear-height-5"></div>
				<div class="content-post">
					<div class="content-post1">
					<div class="clear-height-20">
					<img src="image/post-content1.jpg">
					</div>
					<div class="content-post-title">
						7 Ways To Advertise Your Business For Free
					</div>
					<div class="content-post-date">
						08 Apr 2018
					</div>
					</div>
					<div class="content-post2">
					<div class="clear-height-20">
					<img src="image/post-content2.jpg">
					</div>
					<div class="content-post-title">
						15 Tips To Increase Your Adwords Profits
					</div>
					<div class="content-post-date">
						25 0ct 2018
					</div>
					</div>
					<div class="content-post2">
					<div class="clear-height-20">
					<img src="image/post-content3.jpg">
					</div>
					<div class="content-post-title">
						Direct Mail Advertising How I Made 47 325 In 30 Days By Mailing 2 200 Letters
					</div>
					<div class="content-post-date">
						05 Feb 2018
					</div>
					</div>
					<div class="content-post2">
					<div class="clear-height-20">
					<img src="image/post-content4.jpg">
					</div>
					<div class="content-post-title">
						Free Real Estate Listings
					</div>
					<div class="content-post-date">
						27 Apr 2018
					</div>
					</div>
					<div class="content-post2">
					<div class="clear-height-20">
					<img src="image/post-content5.jpg">
					</div>
					<div class="content-post-title">
						Where To Look For Cheap Brochure Printing Services
					</div>
					<div class="content-post-date">
						19 Mar 2018
					</div>
					</div>
				</div>
				<div class="clear-height-14"></div>
					<img src="image/370x80.jpg">
					<div class="clear-height-14"></div>
					<img src="image/370x80.jpg">
					<div class="clear-height-14"></div>
					<div class="opini">
					<div class="clear-height-13"></div>
					<div class="title">
						OPINI
					</div>
					<div class="clear-height-13"></div>
					</div>
					<div class="opini-content">
						<div class="clear-weight-25">
							<img src="image/opinicontent1.jpg">
							<div class="clear-height-8"></div>
							<div class="opinicontent-title">
								Mg Shadow Computer Monitoring Software A Watchdog Procecting
							</div>
							<div class="clear-height-5"></div>
							<div class="opinicontent-date">01 Oct 2018
							</div>
							<div class="clear-height-5"></div>
							<div class="opinicontent-description">In the last five to six years the FTA satellite receiver has become an everyday household electronic device.People all over the world are buying free air receivers because of their</div>
						</div>
						<div class="clear-weight-25">
							<img src="image/opinicontent2.jpg">
							<div class="clear-height-8"></div>
							<div class="opinicontent-title">
								Video Games Playing With Image
							</div>
							<div class="clear-height-5"></div>
							<div class="opinicontent-date">19 Apr 2018
							</div>
							<div class="clear-height-5"></div>
							<div class="opinicontent-description">Planning to visit Las Vegas are a major portion of their business? I have just the thing for you. Here,I will show you how to pass off</div>
						</div>
					</div>
					<div class="clear-height-20"></div>
					<div class="polling">
						<div class="clear-height-8"></div>
					<div class="title">
						Polling
					</div>
					<div class="clear-height-8"></div>
					</div>
					<div class="polling-content">
						<div class="clear-height-20">
							<form>
								<label>Direct Mail Advertising How I Made 47 325 In 30 Days By Mailing 2 200 Letters?</label>
								<div class="radio"><input type="radio" name="vote" value="profiles">Profiles Of The Powerful Advertising Exec Steve Grasse<br/></div>
								<div class="radio">
								<input type="radio" name="vote" value="feedback">Feedback Management<br/>
								</div>
								<div class="radio">
								<input type="radio" name="vote" value="Adwords">Adwords Keyword Research For Beginners<br/>
								</div>
								<button class="btn btn-orange">
									Vote
								</button>
							</form>
						</div>
					</div>
				</div>
			</div>
</section>