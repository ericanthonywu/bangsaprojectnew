<section class="header">
	<div class="prelatife container">
		<div class="row">
			<div class="col-md-5">
				<a class="navbar-brand" href="">
					<img alt="brand" src="asset/images/logo.jpg">
				</a>
			</div>
			<div class="col-md-7">
				<div class="ads top-page-lay">
					<img alt="brand" src="asset/images/670x88.jpg">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="navbar">
					<ul>
						<li><a href="">JATIM</a></li>
						<li><a href="">NASIONAL</a></li>
						<li><a href="">POLITIK & BIROKRASI</a></li>
						<li><a href="">RELIGIA</a></li>
						<li><a href="">HUKUM & KRIMINAL</a></li>
						<li><a href="">EKONOMI</a></li>
						<li><a href="">SPORTAINMENT</a></li>
						<li><a href="">DUNIA</a></li>
						<li><a href="">INDEKS</a></li>
						<li>
							<a href=""><img src="asset/images/facebook.jpg"></a>
							<a href=""><img src="asset/images/instagram.jpg"></a>
							<a href=""><img src="asset/images/gmail.jpg"></a>
						</li>
					</ul>
					<ul class="bottom">
						<li class="margin-top">
							Trending Topic: It S Hurricane Season But We Are Visiting Hilton Head Island
						</li>
						<li class="margin-top-15">
							<input class="search" type="text" placeholder="Cari" required>
							<button class="button-white"><i class="glyphicon glyphicon-search"></i></button>
						</li>
					</ul>
			</div>
		</div>
	</div>
</section>