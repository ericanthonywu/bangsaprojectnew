<footer>
<section class="footer">
		
	<div class="clear-height-29"></div>
	<div class="container">
		<div class="clear-height-32"></div>
		<div class="row">
			<div class="col-md-5">
				<div class="copyright">
				Copyright &copy; 2018 <a href="">bangsaonline.com</a>
				</div>
			</div>
		<div class="col-md-7">
			<ul class="list-inline">
				<li class="garis"><a href="">Tentang Kami</a></li>
				<li class="garis"><a href="">Kontak Kami</a></li>
				<li class="garis"><a href="">Tarif Iklan</a></li>
				<li class="garis"><a href="">Disclaimer</a></li>
				<li><a href="">Pedoman Media Siber</a></li>
			</ul>
		</div>
		</div>
	</div>
</section>
</footer>